# Height, altitude or depth target.
# Registry type: http://www.opengis.net/def/uxs-command/type/VerticalTarget
float64 value	# m
uint8 reference	# see REFERENCE_*
uint8 REFERENCE_ELLIPSOID = 0
uint8 REFERENCE_MSL = 1
uint8 REFERENCE_TERRAIN = 2
uint8 REFERENCE_HOME = 3
uint8 REFERENCE_DEPTH = 4
uint8 REFERENCE_SEABED = 5
