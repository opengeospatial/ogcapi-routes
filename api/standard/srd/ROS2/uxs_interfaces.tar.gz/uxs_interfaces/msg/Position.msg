# Geographic position with an optional vertical component.
# Registry type: http://www.opengis.net/def/uxs-command/type/Position
float64 latitude	# deg, WGS 84
float64 longitude	# deg, WGS 84
float64 vertical	# m; NaN if unset. Positive up, except depth (positive down).
uint8 vertical_reference	# see VERTICAL_REFERENCE_*
uint8 VERTICAL_REFERENCE_ELLIPSOID = 0
uint8 VERTICAL_REFERENCE_MSL = 1
uint8 VERTICAL_REFERENCE_TERRAIN = 2
uint8 VERTICAL_REFERENCE_HOME = 3
uint8 VERTICAL_REFERENCE_DEPTH = 4
uint8 VERTICAL_REFERENCE_SEABED = 5
uint8 VERTICAL_REFERENCE_UNSET = 255
